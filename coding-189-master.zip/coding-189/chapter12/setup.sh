#/bin/sh

# install some tools
sudo yum install -y git vim gcc glibc-static telnet
