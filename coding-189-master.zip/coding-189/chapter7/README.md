

# RAFT 通俗解释

http://thesecretlivesofdata.com/raft/