本人在Udemy上开设有几门中文课程，设计Python，Docker等领域，欢迎购买

以下课程价格全部9.9美金，或者大家可以微信/支付宝转账49.99给我（转账二维码请点击阅读原文），转账完以后请在udemy上发消息给我，告诉我转账号以及想购买的课程，我会发免费注册课程链接给你。

Python3零基础完全入门

https://www.udemy.com/python3-chinese/?couponCode=SINA-PYTHON3-10


Python高級課程：如何創建/發佈/維護/參與Opensource Software

https://www.udemy.com/python-awesome-tools/?couponCode=OPEN-PYTHON-99


Python3 for Data Science入門與實戰

https://www.udemy.com/python-for-data-science/?couponCode=PYTHON-DATA-SCI99


更多课程敬请期待。

[阅读原文](https://github.com/udemy-course/WeChat-AliPay-QRCode/blob/master/README.md)
